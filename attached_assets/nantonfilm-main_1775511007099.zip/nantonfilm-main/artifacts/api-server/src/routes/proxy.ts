import { Router } from "express";
import axios from "axios";

const router = Router();
const BASE_URL = "https://www.sankavollerei.com/anime/winbu";

async function fetchAPI(path: string, params?: Record<string, string | number | undefined>) {
  const cleanParams: Record<string, string | number> = {};
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== "") cleanParams[k] = v;
    }
  }
  const res = await axios.get(`${BASE_URL}${path}`, {
    params: cleanParams,
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Accept": "application/json",
      "Referer": "https://winbu.net/",
    },
    timeout: 15000,
  });
  return res.data;
}

// Convert numeric-keyed object or array to normalized array with slug
function normalizeList(data: unknown): unknown[] {
  if (!data) return [];
  const arr: unknown[] = Array.isArray(data) ? data : Object.values(data as object);
  return arr.map((item: unknown) => {
    if (item && typeof item === "object") {
      const obj = item as Record<string, unknown>;
      return { ...obj, slug: obj.id || obj.slug };
    }
    return item;
  });
}

// Proxy images to avoid hotlink blocking
router.get("/img", async (req, res) => {
  const { url } = req.query as Record<string, string>;
  if (!url) { res.status(400).send("Missing url"); return; }
  try {
    const response = await axios.get(url, {
      responseType: "arraybuffer",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Referer": "https://winbu.net/",
        "Accept": "image/*,*/*;q=0.8",
      },
      timeout: 10000,
    });
    const contentType = response.headers["content-type"] || "image/jpeg";
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "public, max-age=86400");
    res.send(Buffer.from(response.data));
  } catch {
    res.status(404).send("Image not found");
  }
});

router.get("/home", async (req, res) => {
  try {
    const raw = await fetchAPI("/home");
    const inner = raw?.data || {};
    const data = {
      top10_anime: normalizeList(inner.top10_anime),
      top10_film: normalizeList(inner.top10_film),
      latest_anime: normalizeList(inner.latest_anime),
      latest_film: normalizeList(inner.latest_film),
      latest_series: normalizeList(inner.latest_series),
      tv_show: normalizeList(inner.tv_show),
    };
    res.json({ ok: true, data });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch home");
    res.status(500).json({ ok: false, data: null });
  }
});

router.get("/search", async (req, res) => {
  try {
    const { q, page } = req.query as Record<string, string>;
    const raw = await fetchAPI("/search", { q, page: page ? Number(page) : 1 });
    const data = normalizeList(raw?.data);
    res.json({ ok: true, data, total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to search");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/animedonghua", async (req, res) => {
  try {
    const { page } = req.query as Record<string, string>;
    const raw = await fetchAPI("/animedonghua", { page: page ? Number(page) : 1 });
    res.json({ ok: true, data: normalizeList(raw?.data), total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch animedonghua");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/film", async (req, res) => {
  try {
    const { page } = req.query as Record<string, string>;
    const raw = await fetchAPI("/film", { page: page ? Number(page) : 1 });
    res.json({ ok: true, data: normalizeList(raw?.data), total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch film");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/series", async (req, res) => {
  try {
    const { page } = req.query as Record<string, string>;
    const raw = await fetchAPI("/series", { page: page ? Number(page) : 1 });
    res.json({ ok: true, data: normalizeList(raw?.data), total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch series");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/tvshow", async (req, res) => {
  try {
    const { page } = req.query as Record<string, string>;
    const raw = await fetchAPI("/tvshow", { page: page ? Number(page) : 1 });
    res.json({ ok: true, data: normalizeList(raw?.data), total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch tvshow");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/others", async (req, res) => {
  try {
    const { page } = req.query as Record<string, string>;
    const raw = await fetchAPI("/others", { page: page ? Number(page) : 1 });
    res.json({ ok: true, data: normalizeList(raw?.data), total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch others");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/genres", async (req, res) => {
  try {
    const raw = await fetchAPI("/genres");
    const data = normalizeList(raw?.data);
    res.json({ ok: true, data });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch genres");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/genre/:slug", async (req, res) => {
  try {
    const { slug } = req.params;
    const { page } = req.query as Record<string, string>;
    const raw = await fetchAPI(`/genre/${slug}`, { page: page ? Number(page) : 1 });
    res.json({ ok: true, data: normalizeList(raw?.data), total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch genre");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/schedule", async (req, res) => {
  try {
    const { day } = req.query as Record<string, string>;
    const raw = await fetchAPI("/schedule", { day });
    // schedule data might be keyed by day
    const data = raw?.data;
    res.json({ ok: true, data: typeof data === "object" && !Array.isArray(data) ? data : normalizeList(data) });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch schedule");
    res.status(500).json({ ok: false, data: {} });
  }
});

router.get("/update", async (req, res) => {
  try {
    const raw = await fetchAPI("/update");
    res.json({ ok: true, data: normalizeList(raw?.data) });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch update");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/latest", async (req, res) => {
  try {
    const raw = await fetchAPI("/latest");
    res.json({ ok: true, data: normalizeList(raw?.data) });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch latest");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/ongoing", async (req, res) => {
  try {
    const raw = await fetchAPI("/ongoing");
    res.json({ ok: true, data: normalizeList(raw?.data) });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch ongoing");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/completed", async (req, res) => {
  try {
    const raw = await fetchAPI("/completed");
    res.json({ ok: true, data: normalizeList(raw?.data) });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch completed");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/populer", async (req, res) => {
  try {
    const raw = await fetchAPI("/populer");
    res.json({ ok: true, data: normalizeList(raw?.data) });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch populer");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/all-anime", async (req, res) => {
  try {
    const { page } = req.query as Record<string, string>;
    const raw = await fetchAPI("/all-anime", { page: page ? Number(page) : 1 });
    res.json({ ok: true, data: normalizeList(raw?.data), total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch all-anime");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/catalog", async (req, res) => {
  try {
    const { title, page, order, type, status } = req.query as Record<string, string>;
    const raw = await fetchAPI("/catalog", { title, page: page ? Number(page) : 1, order, type, status });
    res.json({ ok: true, data: normalizeList(raw?.data), total: raw?.total });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch catalog");
    res.status(500).json({ ok: false, data: [] });
  }
});

router.get("/anime/:slug", async (req, res) => {
  try {
    const { slug } = req.params;
    const raw = await fetchAPI(`/anime/${slug}`);
    const d = raw?.data || {};
    const episodes = normalizeList(d.episodes).map((ep: unknown) => {
      const e = ep as Record<string, unknown>;
      return { ...e, slug: e.id || e.slug };
    });
    const recommendations = normalizeList(d.recommendations);
    res.json({ ok: true, data: { ...d, episodes, recommendations } });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch anime detail");
    res.status(500).json({ ok: false, data: null });
  }
});

router.get("/episode/:slug", async (req, res) => {
  try {
    const { slug } = req.params;
    const raw = await fetchAPI(`/episode/${slug}`);
    const d = raw?.data || {};
    res.json({ ok: true, data: d });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch episode");
    res.status(500).json({ ok: false, data: null });
  }
});

router.get("/series/:slug", async (req, res) => {
  try {
    const { slug } = req.params;
    const raw = await fetchAPI(`/series/${slug}`);
    const d = raw?.data || {};
    const episodes = normalizeList(d.episodes).map((ep: unknown) => {
      const e = ep as Record<string, unknown>;
      return { ...e, slug: e.id || e.slug };
    });
    res.json({ ok: true, data: { ...d, episodes } });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch series detail");
    res.status(500).json({ ok: false, data: null });
  }
});

router.get("/film/:slug", async (req, res) => {
  try {
    const { slug } = req.params;
    const raw = await fetchAPI(`/film/${slug}`);
    res.json({ ok: true, data: raw?.data || null });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch film detail");
    res.status(500).json({ ok: false, data: null });
  }
});

router.get("/server", async (req, res) => {
  try {
    const { post, nume, type } = req.query as Record<string, string>;
    const raw = await fetchAPI("/server", { post, nume, type });
    res.json({ ok: true, data: raw });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch server");
    res.status(500).json({ ok: false, data: null });
  }
});

export default router;
