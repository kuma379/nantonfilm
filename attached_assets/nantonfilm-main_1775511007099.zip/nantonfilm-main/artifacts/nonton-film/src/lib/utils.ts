import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function proxyImg(url: string | undefined | null): string {
  if (!url) return "";
  return `/api/img?url=${encodeURIComponent(url)}`;
}
