# NantonFilm

Website streaming Film, Anime, dan Donghua. Dibangun dengan React + Vite + Node.js/Express.

## Fitur
- **Film** — Daftar film dengan pagination
- **Anime & Donghua** — Anime dan film animasi China
- **Series** — Serial TV
- **TV Show** — Acara TV
- **Genre** — Filter berdasarkan genre
- **Jadwal** — Jadwal tayang harian (Senin-Minggu)
- **Pencarian** — Cari konten
- **Halaman Detail** — Info lengkap anime, film, series beserta daftar episode
- **Watch/Player** — Streaming langsung di website

## Stack
- **Frontend**: React + Vite + TailwindCSS + Wouter
- **Backend**: Node.js + Express (proxy ke API eksternal)
- **API**: Axios (fetching data dari API streaming)

---

## Deploy ke Vercel (Auto Update)

### 1. Connect ke Vercel
1. Buka [vercel.com](https://vercel.com) dan login
2. Klik **"Add New Project"**
3. Import repo ini: `kuma379/nantonfilm`
4. Klik **Deploy**

Vercel akan otomatis membaca `vercel.json` di root project.

### 2. Auto Update (GitHub Actions)

Setiap kali ada push ke branch `main`, GitHub Actions akan otomatis deploy ke Vercel.

Untuk mengaktifkan, tambahkan secrets berikut di GitHub repo:
- Buka repo → **Settings** → **Secrets and variables** → **Actions**
- Tambahkan:
  - `VERCEL_TOKEN` — Token dari [vercel.com/account/tokens](https://vercel.com/account/tokens)
  - `VERCEL_ORG_ID` — Dari `~/.vercel/project.json` setelah `vercel link`
  - `VERCEL_PROJECT_ID` — Dari `~/.vercel/project.json` setelah `vercel link`

> **Cara termudah**: Connect langsung di Vercel dashboard (import dari GitHub), maka Vercel akan otomatis deploy tanpa perlu GitHub Actions manual.

---

## Pengembangan Lokal

```bash
# Install dependencies
pnpm install

# Jalankan API server
pnpm --filter @workspace/api-server run dev

# Jalankan frontend
pnpm --filter @workspace/nonton-film run dev
```

## API Endpoints

Backend ini adalah proxy ke `https://www.sankavollerei.com/anime/winbu/` untuk menghindari CORS.

| Endpoint | Keterangan |
|---|---|
| `/api/home` | Data halaman utama |
| `/api/film` | Daftar film |
| `/api/animedonghua` | Anime & Donghua |
| `/api/series` | Series |
| `/api/tvshow` | TV Show |
| `/api/genres` | Semua genre |
| `/api/genre/:slug` | Konten per genre |
| `/api/schedule` | Jadwal siaran |
| `/api/search?q=` | Pencarian |
| `/api/anime/:slug` | Detail anime |
| `/api/film/:slug` | Detail film |
| `/api/series/:slug` | Detail series |
| `/api/episode/:slug` | Detail episode + server |
